"""
GitReverse — turns a GitHub repository into a build prompt.

Run:
    pip install -r requirements.txt
    python app.py
Then open http://127.0.0.1:5000
"""

import json
import os
import re
from urllib.parse import urlparse

import requests
from flask import Flask, jsonify, render_template, request

app = Flask(__name__)

GITHUB_API = "https://api.github.com"
RAW_BASE = "https://raw.githubusercontent.com"

# Optional: set a GITHUB_TOKEN env var to raise the API rate limit
# from 60/hr to 5000/hr and avoid throttling on larger repos.
GITHUB_TOKEN = os.environ.get("GITHUB_TOKEN")


def gh_headers():
    headers = {"Accept": "application/vnd.github+json"}
    if GITHUB_TOKEN:
        headers["Authorization"] = f"Bearer {GITHUB_TOKEN}"
    return headers


class RepoError(Exception):
    def __init__(self, message, status=400):
        super().__init__(message)
        self.message = message
        self.status = status


def parse_repo_input(raw: str) -> tuple[str, str]:
    """Accepts 'owner/repo', a full GitHub URL, or a 'gitreverse.com' URL
    (hub -> reverse swap) and returns (owner, repo)."""
    s = raw.strip()
    if not s:
        raise RepoError("Enter a repository.")

    # Normalize the gitreverse.com -> github.com swap.
    s = re.sub(r"^(https?://)?(www\.)?gitreverse\.com", "github.com", s, flags=re.I)

    if "://" not in s and "github.com" in s.lower():
        s = "https://" + s
    elif "://" not in s and re.match(r"^[\w.-]+/[\w.-]+$", s):
        # bare "owner/repo"
        parts = s.rstrip("/").split("/")
        if len(parts) == 2:
            return parts[0], parts[1].removesuffix(".git")

    parsed = urlparse(s)
    path = parsed.path.strip("/")
    parts = [p for p in path.split("/") if p]
    if len(parts) < 2:
        raise RepoError("Couldn't parse that as owner/repository.")
    owner, repo = parts[0], parts[1].removesuffix(".git")
    return owner, repo


def gh_get(url, params=None):
    resp = requests.get(url, headers=gh_headers(), params=params, timeout=15)
    if resp.status_code == 404:
        raise RepoError("Repository not found. Check the URL and try again.", 404)
    if resp.status_code == 403 and "rate limit" in resp.text.lower():
        raise RepoError(
            "GitHub API rate limit hit. Set a GITHUB_TOKEN env var to raise the limit, "
            "then try again.",
            429,
        )
    if resp.status_code >= 400:
        raise RepoError(f"GitHub API error ({resp.status_code}).", resp.status_code)
    return resp


def fetch_repo_meta(owner, repo):
    resp = gh_get(f"{GITHUB_API}/repos/{owner}/{repo}")
    return resp.json()


def fetch_languages(owner, repo):
    resp = gh_get(f"{GITHUB_API}/repos/{owner}/{repo}/languages")
    return resp.json()


def fetch_tree(owner, repo, branch):
    resp = gh_get(
        f"{GITHUB_API}/repos/{owner}/{repo}/git/trees/{branch}",
        params={"recursive": "1"},
    )
    data = resp.json()
    if data.get("truncated"):
        pass  # tree is huge (e.g. linux); we still use what we got
    return [item["path"] for item in data.get("tree", []) if item["type"] == "blob"]


def fetch_readme_excerpt(owner, repo, max_chars=1200):
    resp = requests.get(
        f"{GITHUB_API}/repos/{owner}/{repo}/readme", headers=gh_headers(), timeout=15
    )
    if resp.status_code != 200:
        return None
    import base64

    data = resp.json()
    try:
        text = base64.b64decode(data["content"]).decode("utf-8", errors="ignore")
    except Exception:
        return None
    text = re.sub(r"<[^>]+>", "", text)  # strip stray HTML
    text = text.strip()
    if len(text) > max_chars:
        text = text[:max_chars].rsplit("\n", 1)[0] + "\n…"
    return text


def fetch_raw(owner, repo, branch, path):
    resp = requests.get(f"{RAW_BASE}/{owner}/{repo}/{branch}/{path}", timeout=15)
    if resp.status_code == 200:
        return resp.text
    return None


DEP_FILES = [
    "package.json",
    "requirements.txt",
    "pyproject.toml",
    "Pipfile",
    "Cargo.toml",
    "go.mod",
    "composer.json",
    "Gemfile",
    "pom.xml",
    "build.gradle",
]


def find_dependency_files(paths):
    top_level = {p for p in paths if "/" not in p}
    return [f for f in DEP_FILES if f in top_level]


# filename -> short human description, used to annotate config/build files
# found anywhere in the tree (matched on basename).
CONFIG_FILES = {
    "manage.py": "Django management entry point",
    "settings.py": "Django settings module",
    "wsgi.py": "WSGI application entry point",
    "asgi.py": "ASGI application entry point",
    "tsconfig.json": "TypeScript compiler config",
    "next.config.js": "Next.js config",
    "next.config.ts": "Next.js config",
    "vite.config.js": "Vite build config",
    "vite.config.ts": "Vite build config",
    "webpack.config.js": "Webpack build config",
    "tailwind.config.js": "Tailwind CSS config",
    "babel.config.js": "Babel transpiler config",
    "jest.config.js": "Jest test config",
    ".eslintrc.json": "ESLint config",
    ".eslintrc.js": "ESLint config",
    "docker-compose.yml": "Docker Compose services",
    "docker-compose.yaml": "Docker Compose services",
    "Dockerfile": "Container build definition",
    "Makefile": "Build/task automation",
    "pytest.ini": "Pytest config",
    "tox.ini": "Tox test automation config",
    "CMakeLists.txt": "CMake build config",
    "pom.xml": "Maven build config",
    "build.gradle": "Gradle build config",
    "Cargo.toml": "Rust package manifest",
    "go.mod": "Go module definition",
    "pyproject.toml": "Python packaging/tooling config",
    ".pre-commit-config.yaml": "Pre-commit hook config",
}

# Common entry-point filenames by convention, checked as exact repo paths.
ENTRY_POINT_CANDIDATES = [
    "manage.py",
    "main.py",
    "app.py",
    "wsgi.py",
    "asgi.py",
    "bin/www",
    "index.js",
    "index.ts",
    "index.mjs",
    "server.js",
    "server.ts",
    "src/index.js",
    "src/index.ts",
    "src/main.js",
    "src/main.ts",
    "src/main.rs",
    "main.go",
    "cmd/main.go",
    "Program.cs",
]


def detect_entry_points(paths):
    path_set = set(paths)
    return [c for c in ENTRY_POINT_CANDIDATES if c in path_set]


def detect_config_files(paths, limit=15):
    found = []
    for p in paths:
        base = p.rsplit("/", 1)[-1]
        if base in CONFIG_FILES:
            found.append((p, CONFIG_FILES[base]))
    return found[:limit]


def detect_ci_workflows(paths):
    return [p for p in paths if p.startswith(".github/workflows/") and p.endswith((".yml", ".yaml"))]


def parse_entry_hints(filename, content):
    """Pull run/start commands out of an already-fetched dependency manifest."""
    hints = []
    try:
        if filename == "package.json":
            data = json.loads(content)
            if data.get("main"):
                hints.append(f"package.json main: {data['main']}")
            scripts = data.get("scripts", {})
            for key in ("start", "dev", "serve"):
                if key in scripts:
                    hints.append(f"npm run {key} -> {scripts[key]}")
        elif filename == "pyproject.toml":
            m = re.search(r"\[project\.scripts\]\s*\n(.*?)(\n\[|\Z)", content, re.S)
            if m:
                for line in m.group(1).splitlines():
                    line = line.strip()
                    if line and "=" in line:
                        hints.append(f"console script: {line}")
    except Exception:
        pass
    return hints


def build_tree(paths):
    """Nested dict tree: directories map to sub-dicts, files map to None."""
    tree = {}
    for p in paths:
        parts = p.split("/")
        node = tree
        for part in parts[:-1]:
            node = node.setdefault(part, {})
        if isinstance(node, dict):
            node.setdefault(parts[-1], None)
    return tree


def render_tree(tree, prefix="", depth=0, max_depth=3, max_entries=10, lines=None):
    if lines is None:
        lines = []
    if depth >= max_depth or not isinstance(tree, dict):
        return lines
    # directories first, then files, alphabetically within each group
    entries = sorted(tree.items(), key=lambda kv: (kv[1] is None, kv[0].lower()))
    shown, hidden = entries[:max_entries], len(entries) - max_entries
    for name, sub in shown:
        is_dir = sub is not None
        lines.append(f"{prefix}{name}{'/' if is_dir else ''}")
        if is_dir:
            render_tree(sub, prefix + "  ", depth + 1, max_depth, max_entries, lines)
    if hidden > 0:
        lines.append(f"{prefix}… {hidden} more")
    return lines


def parse_dependencies(filename, content):
    names = []
    try:
        if filename == "package.json":
            data = json.loads(content)
            for key in ("dependencies", "devDependencies"):
                names.extend(data.get(key, {}).keys())
        elif filename == "requirements.txt":
            for line in content.splitlines():
                line = line.strip()
                if line and not line.startswith("#"):
                    names.append(re.split(r"[=<>~\[; ]", line)[0])
        elif filename == "pyproject.toml":
            for m in re.finditer(r'^\s*"?([A-Za-z0-9_.-]+)"?\s*=\s*[">^~]', content, re.M):
                names.append(m.group(1))
        elif filename == "Cargo.toml":
            in_deps = False
            for line in content.splitlines():
                if line.strip().startswith("[dependencies"):
                    in_deps = True
                    continue
                if line.strip().startswith("[") and in_deps:
                    in_deps = False
                if in_deps and "=" in line:
                    names.append(line.split("=")[0].strip())
        elif filename == "go.mod":
            for m in re.finditer(r"^\s*([\w./-]+)\s+v[\d.]+", content, re.M):
                names.append(m.group(1))
        elif filename == "composer.json":
            data = json.loads(content)
            for key in ("require", "require-dev"):
                names.extend(data.get(key, {}).keys())
        elif filename == "Gemfile":
            for m in re.finditer(r'gem\s+["\']([\w-]+)["\']', content):
                names.append(m.group(1))
    except Exception:
        pass
    return [n for n in names if n][:40]


TEST_PATTERNS = re.compile(r"(^|/)(tests?|spec|__tests__)(/|$)|\.(test|spec)\.", re.I)


def fetch_open_issues(owner, repo, limit=5):
    resp = requests.get(
        f"{GITHUB_API}/repos/{owner}/{repo}/issues",
        headers=gh_headers(),
        params={"state": "open", "per_page": limit, "sort": "comments", "direction": "desc"},
        timeout=15,
    )
    if resp.status_code != 200:
        return []
    return [i["title"] for i in resp.json() if "pull_request" not in i][:limit]


def build_prompt(owner, repo, options):
    meta = fetch_repo_meta(owner, repo)
    branch = meta.get("default_branch", "main")
    full_name = meta.get("full_name", f"{owner}/{repo}")
    description = meta.get("description") or "No description provided."
    paths = fetch_tree(owner, repo, branch)

    # Fetch each present dependency manifest once, reused by both the
    # dependencies section and entry-point detection below.
    dep_files = find_dependency_files(paths)
    dep_contents = {}
    for fname in dep_files:
        content = fetch_raw(owner, repo, branch, fname)
        if content:
            dep_contents[fname] = content

    lines = [
        f"PROJECT: {meta.get('name', repo)}",
        f"SOURCE: github.com/{full_name}",
        f"DESCRIPTION: {description}",
        "",
        "You are rebuilding this project from scratch. Use the context below as "
        "ground truth for structure, stack, and intent. Ask before deviating from it.",
    ]

    if options.get("architecture", True):
        lines.append("\nARCHITECTURE")

        tree = build_tree(paths)
        tree_lines = render_tree(tree, max_depth=3, max_entries=10)
        lines.append("Directory tree (depth 3, top entries per folder):")
        lines.extend(tree_lines)

        entry_points = detect_entry_points(paths)
        for fname, content in dep_contents.items():
            entry_points_from_manifest = parse_entry_hints(fname, content)
            if entry_points_from_manifest:
                entry_points = entry_points + entry_points_from_manifest
        if entry_points:
            lines.append("\nEntry points:")
            for ep in entry_points:
                lines.append(f"  - {ep}")

        config_files = detect_config_files(paths)
        ci_workflows = detect_ci_workflows(paths)
        if config_files or ci_workflows:
            lines.append("\nConfig & build files:")
            for path, desc in config_files:
                lines.append(f"  - {path} — {desc}")
            if ci_workflows:
                shown = [w.rsplit("/", 1)[-1] for w in ci_workflows[:6]]
                extra = len(ci_workflows) - len(shown)
                lines.append(
                    f"  - .github/workflows/ — CI (GitHub Actions): "
                    + ", ".join(shown)
                    + (f" …+{extra} more" if extra > 0 else "")
                )

    if options.get("dependencies", True):
        languages = fetch_languages(owner, repo)
        lines.append("\nDEPENDENCIES")
        if languages:
            total = sum(languages.values()) or 1
            lang_line = ", ".join(
                f"{lang} ({bytes_ * 100 // total}%)"
                for lang, bytes_ in sorted(languages.items(), key=lambda kv: -kv[1])[:6]
            )
            lines.append(f"Languages: {lang_line}")
        for fname, content in dep_contents.items():
            deps = parse_dependencies(fname, content)
            if deps:
                lines.append(f"From {fname}: " + ", ".join(deps[:25]) + (" …" if len(deps) > 25 else ""))

    if options.get("structure", True):
        lines.append("\nFILE COUNT")
        lines.append(f"{len(paths)} tracked files across the repository.")

    if options.get("tests", False):
        test_files = [p for p in paths if TEST_PATTERNS.search(p)]
        lines.append("\nTESTING")
        if test_files:
            lines.append(f"{len(test_files)} test-related files detected, e.g.:")
            for p in test_files[:8]:
                lines.append(f"  - {p}")
        else:
            lines.append("No obvious test directory or test-named files detected.")

    if options.get("setup", True):
        readme = fetch_readme_excerpt(owner, repo)
        lines.append("\nSETUP")
        has_docker = any(p.lower() in ("dockerfile", "docker-compose.yml", "docker-compose.yaml") for p in paths)
        has_env_example = any(p.lower().endswith(".env.example") or p.lower() == ".env.example" for p in paths)
        lines.append(f"Docker config present: {'yes' if has_docker else 'no'}")
        lines.append(f".env.example present: {'yes' if has_env_example else 'no'}")
        if readme:
            lines.append("README excerpt:")
            lines.append(readme)

    if options.get("issues", True):
        issues = fetch_open_issues(owner, repo)
        lines.append("\nOPEN ITEMS")
        if issues:
            for title in issues:
                lines.append(f"  - {title}")
        else:
            lines.append("No open issue titles retrieved.")

    lines.append(
        f"\nTASK\nRecreate {meta.get('name', repo)} as a working build, matching its "
        "structure and behavior as closely as the above context allows."
    )

    return "\n".join(lines), meta


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/generate", methods=["POST"])
def api_generate():
    body = request.get_json(silent=True) or {}
    raw_repo = body.get("repo", "")
    options = body.get("options", {})

    try:
        owner, repo = parse_repo_input(raw_repo)
        prompt, meta = build_prompt(owner, repo, options)
    except RepoError as e:
        return jsonify({"error": e.message}), e.status
    except requests.RequestException:
        return jsonify({"error": "Couldn't reach GitHub. Check your connection and try again."}), 502

    return jsonify(
        {
            "prompt": prompt,
            "repo": f"{owner}/{repo}",
            "stars": meta.get("stargazers_count"),
            "default_branch": meta.get("default_branch"),
        }
    )


if __name__ == "__main__":
    app.run(debug=True)
