# GitReverse

Turns a GitHub repository into a build prompt, using the real GitHub API.

## Run it

```bash
cd gitreverse-app
pip install -r requirements.txt
python app.py
```

Open http://127.0.0.1:5000

## Notes

- Uses the public GitHub REST API — no auth needed, but unauthenticated
  requests are capped at 60/hour per IP. If you hit that limit, set a
  personal access token (no scopes needed for public repos) as an
  environment variable before running:

  ```bash
  export GITHUB_TOKEN=ghp_xxxxxxxx   # macOS/Linux
  set GITHUB_TOKEN=ghp_xxxxxxxx      # Windows
  ```

  This raises the limit to 5,000/hour.

- Paste any `github.com/owner/repo` URL, a bare `owner/repo`, or swap
  "hub" for "reverse" in the URL — all three are accepted.
- "Manual control" toggles which sections (architecture, dependencies,
  file structure, tests, setup, open issues) get pulled into the prompt.
  Tests, setup, and open-issue lookups are off by default since they
  cost extra API calls.
