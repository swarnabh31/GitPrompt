const form = document.getElementById('prompt-form');
const input = document.getElementById('repo-input');
const generateBtn = document.getElementById('generate-btn');
const manualToggle = document.getElementById('manual-toggle');
const manualPanel = document.getElementById('manual-panel');
const formHint = document.getElementById('form-hint');
const result = document.getElementById('result');
const resultTitle = document.getElementById('result-title');
const promptOutput = document.getElementById('prompt-output');
const copyBtn = document.getElementById('copy-btn');
const chips = document.querySelectorAll('.chip');

const defaultHint = formHint.textContent;

manualToggle.addEventListener('click', () => {
  manualPanel.classList.toggle('open');
});

function getOptions() {
  const options = {};
  manualPanel.querySelectorAll('input[type="checkbox"]').forEach((cb) => {
    options[cb.name] = cb.checked;
  });
  return options;
}

function setLoading(isLoading) {
  generateBtn.disabled = isLoading;
  chips.forEach((c) => (c.disabled = isLoading));
  generateBtn.innerHTML = isLoading ? '<span class="spinner"></span>Generating…' : 'Get prompt';
}

function setHint(message, isError) {
  formHint.textContent = message;
  formHint.classList.toggle('error', !!isError);
}

async function generate(rawValue) {
  if (!rawValue || !rawValue.trim()) {
    input.focus();
    return;
  }
  setLoading(true);
  setHint('Reading the repository from GitHub…', false);
  result.classList.remove('open');

  try {
    const res = await fetch('/api/generate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ repo: rawValue, options: getOptions() }),
    });
    const data = await res.json();

    if (!res.ok) {
      setHint(data.error || 'Something went wrong.', true);
      return;
    }

    resultTitle.textContent = `Prompt for ${data.repo}`;
    promptOutput.textContent = data.prompt;
    result.classList.add('open');
    setHint(defaultHint, false);
    result.scrollIntoView({ behavior: 'smooth', block: 'start' });
  } catch (err) {
    setHint("Couldn't reach the server. Is the Flask app running?", true);
  } finally {
    setLoading(false);
  }
}

form.addEventListener('submit', (e) => {
  e.preventDefault();
  generate(input.value);
});

chips.forEach((chip) => {
  chip.addEventListener('click', () => {
    input.value = chip.dataset.repo;
    generate(chip.dataset.repo);
  });
});

copyBtn.addEventListener('click', () => {
  navigator.clipboard.writeText(promptOutput.textContent).then(() => {
    const original = copyBtn.textContent;
    copyBtn.textContent = 'Copied';
    setTimeout(() => {
      copyBtn.textContent = original;
    }, 1500);
  });
});
